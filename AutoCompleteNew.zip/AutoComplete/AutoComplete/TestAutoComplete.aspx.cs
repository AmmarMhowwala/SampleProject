﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AutoComplete
{
    public partial class TestAutoComplete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ddlDropDown.Items.Add(new ListItem("Select City", "0"));
            ddlDropDown.Items.Add(new ListItem("Indore", "1"));
            ddlDropDown.Items.Add(new ListItem("Mumbai", "2"));
            ddlDropDown.Items.Add(new ListItem("Pune", "3"));
            ddlDropDown.Items.Add(new ListItem("Kolkata", "4"));
            ddlDropDown.Items.Add(new ListItem("Madras", "5"));
            ddlDropDown.Items.Add(new ListItem("Lucknow", "6"));
            ddlDropDown.Items.Add(new ListItem("Kanpur", "7"));
            ddlDropDown.Items.Add(new ListItem("Delhi", "8"));
            ddlDropDown.Items.Add(new ListItem("Nagpur", "9"));
        }

        [WebMethod]
        public static List<ListItem> GetCustomers()
        {
            List<ListItem> customers = new List<ListItem>();
            customers.Add(new ListItem
            {
                Text= "enhancement",
                Value ="0" ,
            });
            customers.Add(new ListItem
            {
                Text = "enhancement1",
                Value = "1",
            });

          
            return customers;
        }
    }
}