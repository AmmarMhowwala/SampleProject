﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace Sample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DispatcherTimer timer;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            
            InitializeComponent();
             timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
           
            if (txtTolerance.IsEnabled)
            {
                btnStart.Content = "Stop";
                Style style = this.FindResource("StopBtn") as Style;
                btnStart.Style = style;
                timer.Start();
               
            }
            else
            {
                btnStart.Content = "Start";
                Style style = this.FindResource("StartBtn") as Style;
                btnStart.Style = style;
                
               
            }
            double primary = Convert.ToDouble(txtPrimary.Text);
            double secondary = Convert.ToDouble(txtSecondary.Text);

            double tolerance = Convert.ToDouble(txtTolerance.Text);
            upperLimitPrimary = primary + tolerance;
            lowerLimitPrimary = primary - tolerance;
            upperLimitSecondary = secondary + tolerance;
            lowerLimitSecondary = secondary - tolerance;
            txtPrimary.IsEnabled = !txtPrimary.IsEnabled;
            txtSecondary.IsEnabled = !txtSecondary.IsEnabled;
            txtStep.IsEnabled = !txtStep.IsEnabled;
            txtTolerance.IsEnabled = !txtTolerance.IsEnabled;
            btnPrimaryIncrease.IsEnabled = !btnPrimaryIncrease.IsEnabled;
            btnSecondaryIncrease.IsEnabled = !btnSecondaryIncrease.IsEnabled;
            btnStepIncrease.IsEnabled = !btnStepIncrease.IsEnabled;
            btnToleranceIncrease.IsEnabled = !btnToleranceIncrease.IsEnabled;
            btnPrimaryDecrease.IsEnabled = !btnPrimaryDecrease.IsEnabled;
            btnSecondaryDecrease.IsEnabled = !btnSecondaryDecrease.IsEnabled;
            btnStepDecrease.IsEnabled = !btnStepDecrease.IsEnabled;
            btnToleranceDecrease.IsEnabled = !btnToleranceDecrease.IsEnabled;
            flagPrimary = true;
            flagSecondary = true;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            double primary = Convert.ToDouble(txtPrimary.Text);
            double secondary = Convert.ToDouble(txtSecondary.Text);
            double step = Convert.ToDouble(txtStep.Text);
            if (txtPrimary.IsEnabled == true)
            {
                (sender as DispatcherTimer).Stop();
            }
            if (primary < upperLimitPrimary && flagPrimary)
                {
                        primary = primary + step;
                        if (primary > upperLimitPrimary)
                        {
                            txtPrimary.Text = Convert.ToString(upperLimitPrimary);

                        }
                        else
                            txtPrimary.Text = Convert.ToString(primary);
                    
                        if (primary >= upperLimitPrimary)
                            flagPrimary = false;
                }
            else if (primary > lowerLimitPrimary && !flagPrimary)
                {
                        primary = primary - step;
                        if (primary < lowerLimitPrimary)
                        {
                            txtPrimary.Text = Convert.ToString(lowerLimitPrimary);

                        }
                        else
                            txtPrimary.Text = Convert.ToString(primary);

               
                        if (primary <= lowerLimitPrimary)
                            flagPrimary = true;
                }

                if (secondary < upperLimitSecondary && flagSecondary)
                {
                        secondary = secondary + step;
                        if (secondary > upperLimitSecondary)
                        {
                            txtSecondary.Text = Convert.ToString(upperLimitSecondary);

                        }
                        else
                            txtSecondary.Text = Convert.ToString(secondary);

                        if (secondary >= upperLimitSecondary)
                            flagSecondary = false;
            }
                else if (secondary > lowerLimitSecondary && !flagSecondary)
                {
                        secondary = secondary - step;
                        if (secondary < lowerLimitSecondary)
                        {
                            txtSecondary.Text = Convert.ToString(lowerLimitSecondary);

                        }
                        else
                            txtSecondary.Text = Convert.ToString(secondary);


                        if (secondary <= lowerLimitSecondary)
                            flagSecondary = true;
            }
        }

        private double _primary = 0;

        public double Primary
        {
            get { return _primary; }
            set
            {
                _primary = value;
                txtPrimary.Text = value.ToString();
                
            }
        }
        private double _Tolerance = 0;

        public double Tolerance
        {
            get { return _Tolerance; }
            set
            {
                _Tolerance = value;
                txtTolerance.Text = value.ToString();

            }
        }
        private double _Secondary = 0;

        public double Secondary
        {
            get { return _Secondary; }
            set
            {
                _Secondary = value;
                txtSecondary.Text = value.ToString();

            }
        }

        private double _Step = 0;

        public double Step
        {
            get { return _Step; }
            set
            {
                _Step = value;
                txtStep.Text = value.ToString();

            }
        }

        public double upperLimitPrimary=0;
        public double lowerLimitPrimary = 0;
        public double upperLimitSecondary = 0;
        public double lowerLimitSecondary =0;
        public Boolean flagPrimary = true;
        public Boolean flagSecondary = true;

        private void txtPrimary_TextChanged(object sender, TextChangedEventArgs e)
        {


            if (double.TryParse(txtPrimary.Text, out _primary))
            {
                if (_primary <= 100 && _primary >= -20)
                {
                    txtPrimary.Text = _primary.ToString();
                }
                else
                {
                    MessageBox.Show("Primary temperature is greater than -20 and less than 100");
                    txtPrimary.Text = "0";
                }
            }
            else
            {
                MessageBox.Show("Please enter numeric value");
                txtPrimary.Text = "0";
            }
        }

        private void txtSecondary_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (double.TryParse(txtSecondary.Text, out _Secondary))
            {
                if (_Secondary <= 100 && _Secondary >= -20)
                {
                    txtSecondary.Text = _Secondary.ToString();
                }
                else
                {
                    MessageBox.Show("Secondary temperature is greater than -20 and less than 100");
                    txtSecondary.Text = "0";
                }
            }
            else
            {
                MessageBox.Show("Please enter numeric value");
                txtSecondary.Text = "0";
            }
        }

        private void txtTolerance_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (double.TryParse(txtTolerance.Text, out _Tolerance))
            {
                if (_Tolerance >= 1 && _Tolerance <= 10)
                {
                    txtTolerance.Text = _Tolerance.ToString();
                }
                else
                {

                    MessageBox.Show("Tolerance is greater than 1 and less than 10");
                    txtTolerance.Text = "1";
                }

            }
            else
            {
                MessageBox.Show("Please enter numeric value");
                txtTolerance.Text = "1";
            }
        }

        private void txtStep_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (double.TryParse(txtStep.Text, out _Step))
            {
                if (_Step >= 0.1 && _Step <= 0.9)
                {
                    txtStep.Text = _Step.ToString();
                }
                else
                {
                    MessageBox.Show("Step value is greater than 0.1 and less than 0.9");
                    txtStep.Text = "0.1";
                }
            }
            else
                MessageBox.Show("Please enter numeric value");
        }

        private void btnSecondaryIncrease_Click(object sender, RoutedEventArgs e)
        {
            Secondary++;
        }

        private void btnSecondaryDecrease_Click(object sender, RoutedEventArgs e)
        {
            Secondary--;
        }

        private void btnPrimaryIncrease_Click(object sender, RoutedEventArgs e)
        {
            Primary++;
        }

        private void btnPrimaryDecrease_Click(object sender, RoutedEventArgs e)
        {
            Primary--;
        }

        private void btnToleranceIncrease_Click(object sender, RoutedEventArgs e)
        {
            Tolerance++;
        }

        private void btnToleranceDecrease_Click(object sender, RoutedEventArgs e)
        {
            Tolerance--;
        }

        private void btnStepIncrease_Click(object sender, RoutedEventArgs e)
        {
            Step=Step+0.1;
        }

        private void btnStepDecrease_Click(object sender, RoutedEventArgs e)
        {
            Step = Step - 0.1; 
        }
    }
}
