﻿using MVCDemoWithEF_03082016.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCDemoWithEF_03082016.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        StudentDemoEntities db = new StudentDemoEntities();

        public ActionResult EmployeeList()
        {
            List<employee_SelectEmployeeDetails_Result> lst = new List<employee_SelectEmployeeDetails_Result>();
            lst = db.employee_SelectEmployeeDetails().ToList();
            return View(lst);
        }

        //[HttpGet]
        //public ActionResult EmployeeList()
        //{
        //    return View();
        //}

        public ActionResult SelectEmployee()
        {
            List<employee_SelectEmployeeDetails_Result> lst = new List<employee_SelectEmployeeDetails_Result>();
            lst = db.employee_SelectEmployeeDetails().ToList();
            var data = lst;
            return Json(new { data = data }, JsonRequestBehavior.AllowGet);

        } 

        public ActionResult AddEmployee()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddEmployee(EmployeeDetails objEmployee)
        {
            if (ModelState.IsValid)
            {
               ObjectParameter objParam = new ObjectParameter("employeeID", typeof(int));
               int res = db.employee_SaveEmployeedetail(objEmployee.EmployeeId, objEmployee.EmployeeName, objEmployee.BasicSalary, objEmployee.VariableAllowance, objEmployee.EmployeeDesignation, objParam);
               this.db.SaveChanges();
               int lstEmployeeId = Convert.ToInt32(objParam.Value);
               objEmployee.EmployeeId = lstEmployeeId;
            }
            return View(objEmployee);
        }

        public ActionResult UpdateEmployee(int? id)
        {
            if (id != null)
            {
                Employee_GetEmployeeDetailByEmployeeID_Result objEmployee = new Employee_GetEmployeeDetailByEmployeeID_Result();
                objEmployee = db.Employee_GetEmployeeDetailByEmployeeID(id).FirstOrDefault();
                return View(objEmployee);
            }
            return View();
        }

        [HttpPost]
        public ActionResult UpdateEmployee(Employee_GetEmployeeDetailByEmployeeID_Result objEmployee)
        {
            if (ModelState.IsValid)
            {
                ObjectParameter objParam = new ObjectParameter("employeeID", typeof(int));
                int res = db.employee_SaveEmployeedetail(objEmployee.EmployeeId, objEmployee.EmployeeName, objEmployee.BasicSalary, objEmployee.VariableAllowance, objEmployee.EmployeeDesignation, objParam);
                this.db.SaveChanges();
                int lstEmployeeId = Convert.ToInt32(objParam.Value);
                objEmployee.EmployeeId = lstEmployeeId;
            }
            return View(objEmployee);
        }

        public ActionResult DeleteEmployee(int? id)
        {
            if (id != null)
            {
                Employee_GetEmployeeDetailByEmployeeID_Result objEmployee = new Employee_GetEmployeeDetailByEmployeeID_Result();
                objEmployee = db.Employee_GetEmployeeDetailByEmployeeID(id).FirstOrDefault();
                EmployeeDetails ed = new EmployeeDetails();                
                return View(objEmployee);
            }
            return View();
        }

        [HttpPost]
        public ActionResult DeleteEmployee(Employee_GetEmployeeDetailByEmployeeID_Result objEmployee)
        {
            if (ModelState.IsValid)
            {               
                int res = db.Employee_DeleteEmployeeDetails(objEmployee.EmployeeId);
                this.db.SaveChanges();              
            }
            return RedirectToAction("EmployeeList");
        }
    }
}