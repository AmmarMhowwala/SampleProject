﻿using System.Web.UI;

namespace AutoComplete.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}